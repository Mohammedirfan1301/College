/*
 * Your implementation of mystring.c should replace this file
 */
