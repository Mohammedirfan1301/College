#include <stdio.h>
#include <stdlib.h>
#include "my_set.h"

typedef struct node Node;

// TREE STRUCTURE.
struct node
{
	int data;		// Each node contains an int, and left / right pointers.
	Node * left;	// which point to another node and so on.
	Node * right;		
};

struct my_set
{
	Node * root;	
};

typedef struct my_set My_set;

//	 Function declarations
void in_order_traverse(Node* root, void (*visit)(int));
void destroy(Node* root);

// Takes no arguments; returns a handle to a default MY_SET
MY_SET my_set_init_default(void)
{
	My_set * temp;	
	temp  = (My_set*)malloc(sizeof(My_set));	// Alloc space for a MY_SET
	
	// See if the malloc failed:
	if(temp == NULL)
	{
		printf("Error - failed to malloc default MY_SET object!\n");
		return NULL;
	}
	
	// If it succeded, then we are free to set root to NULL
	if(temp != NULL)
	{
		temp->root = NULL;
	}
	
	// And return a handle to the MY_SET object!
	return (MY_SET)temp;
}

// Returns TRUE if item is in the set; exit on error
Boolean my_set_is_element(MY_SET hMY_SET, int item)	
{

//	Hmm... Need to traverse the list and see if we find item.

//	Failed to find the item!
	return FALSE;
}

// Returns TRUE if the set is empty; exit on error
Boolean my_set_is_empty(MY_SET hMY_SET)		
{
//	If MY_SET is NULL, there is no list.
	if(hMY_SET == NULL)
	{
		return FALSE;
	}
	
//	If it isn't NULL, there is some sort of a list.
	return TRUE;
}

// Returns the number of elements in the set; -1 on error
int my_set_size(MY_SET hMY_SET)			
{

	// Need to figure this one out.

	int number_of_nodes = 0;
	//Node top;
	//top = hMY_SET->root;
	
	// Verify that hMY_SET exists.
	if(hMY_SET == NULL)
		return -1;	// Return error if it doesn't.
	
	// Assuming we have at least one node, run through the tree.
	// (Using pre-order)
	/*
	while(hMY_SET != NULL || hMY_SET->root != NULL)
	{
		visit(hMY_SET->root);
		if(top->right != NULL)
			visit(
		
		number_of_nodes++;
	}
	*/
	return number_of_nodes;
}

// Call visit on each node in the set. (Inorder traversal)
Status my_set_traverse(MY_SET hMY_SET, void (*visit)(int))
{
	My_set * temp = (My_set*) hMY_SET;

	if (temp != NULL) 	// Make sure the set isn't empty!
	{
		in_order_traverse(temp->root, visit);	// Another function will do the work.
		return SUCCESS;
	}

	return FAILURE;		// If temp was NULL, must return a FAILURE. 
}

// Traverse the list in order of the Nodes.
void in_order_traverse(Node* root, void (*visit)(int))
{
	if(root == NULL)	// Can't traverse an empty set!
	{
		return;
	}
	else
	{
		in_order_traverse(root->left, visit);	// Traverse left side.
		visit(root->data);						// Then visit root.
		in_order_traverse(root->right, visit);	// Traverse right side.
		return;
	}
}

// Adds item to the set if it is not already in it.
Status my_set_add(MY_SET hMY_SET, int item)		
{
	if(hMY_SET == NULL)
	{
		// Need to make the first node if the set is empty!
	}
	// Other wise we can just see if there's room somewhere, left / right etc.

	return FAILURE;
}

// Find and remove item from the set if it is present. Otherwise ignore.
Status my_set_remove(MY_SET hMY_SET, int item)		
{
	// If the set is empty, don't bother searching!
	if(hMY_SET == NULL)
	{
		return FAILURE;
	}
	
	// Other wise go through the list and try to find the item.
	
	// ... le code
	
	// If we don't find it, return FAILURE.
	return FAILURE;
}

// Destroy the data structure and set the handle pointed to by the arg to NULL.
void my_set_destroy(MY_SET* p_hMY_SET)			
{
	My_set * temp = (My_set*)*p_hMY_SET;

	if(temp != NULL)
	{
		destroy(temp->root);
		free(temp);
	}

	*p_hMY_SET = NULL;
	return;
}

// Function called by my_set_destroy
void destroy(Node* root)
{
	if(root == NULL)
	{
		return;
	}
	else
	{
		destroy(root->left);
		destroy(root->right);
		free(root);
	}
}

/* Return the height of the AVL Tree implementation.
  (An empty tree has height 0, a tree with one node has height 1)	*/
int my_set_height(MY_SET hMY_SET)			
{	
	// If the set pointer is NULL, well the list is empty!
	if(hMY_SET == NULL)
	{				
		return 0;
	}
	
	// Otherwise, search through the list level by level.
	// Once we hit the max level, we can return the # of levels.
	
	// Return 0 for now.
	return 0;
}		
