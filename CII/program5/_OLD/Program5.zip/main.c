#include <stdio.h>
#include <stdlib.h>
#include "my_set.h"

void printNumber(int num)
{
	printf("%d\n", num);
	return;
}

int main(int argc, char * argv[])
{
	MY_SET hSet;
	
	hSet = my_set_init_default();
	
	my_set_traverse(hSet, printNumber);

	my_set_destroy(&hSet);
	return 0;
}
