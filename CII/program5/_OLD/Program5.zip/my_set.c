#include <stdio.h>
#include <stdlib.h>
#include "my_set.h"

typedef struct node Node;

struct node
{
	int data;
	Node * left;
	Node * right;		
};

struct my_set
{
	Node * root;
};

typedef struct my_set My_set;

MY_SET my_set_init_default()
{
	My_set * temp;	
	temp  = (My_set*)malloc(sizeof(My_set));
	
	if(temp != NULL)
	{
		temp->root = NULL;
	}
	
	return (MY_SET)temp;
}

void in_order_traverse(Node* root, void (*visit)(int));

void destroy(Node* root);

Boolean my_set_is_element(MY_SET hMY_SET, int item)	//returns TRUE if item is in the set; exit on error
{
	return FALSE;
}

Boolean my_set_is_empty(MY_SET hMY_SET)		//returns TRUE if the set is empty; exit on error
{
	return FALSE;
}

int my_set_size(MY_SET hMY_SET)			//returns the number of elements in the set; -1 on error
{
	return 0;
}

Status my_set_traverse(MY_SET hMY_SET, void (*visit)(int))//call visit on each node in the set. (Inorder traversal)
{
	My_set * temp = (My_set*) hMY_SET;

	if (temp != NULL)
	{
		in_order_traverse(temp->root, visit);
		return SUCCESS;
	}

	return FAILURE;
}

void in_order_traverse(Node* root, void (*visit)(int))
{
	if( root == NULL)
	{
		return;
	}
	else
	{
		in_order_traverse(root->left, visit);
		visit(root->data);
		in_order_traverse(root->right, visit);
		return;
}
}

Status my_set_add(MY_SET hMY_SET, int item)		//adds item to the set if it is not already in it.
{
	return FAILURE;
}

Status my_set_remove(MY_SET hMY_SET, int item)		//find and remove item from the set if it is present. otherwise ignore
{
	
	return FAILURE;
}

void my_set_destroy(MY_SET* p_hMY_SET)			//destroy the data structure and set the handle pointed to by the arg to NULL
{
	My_set * temp = (My_set*)*p_hMY_SET;

	if(temp != NULL)
	{
		destroy(temp->root);
		free(temp);
	}

	*p_hMY_SET = NULL;
	return;
}

void destroy(Node* root)
{
	if(root == NULL)
	{
		return;
	}
	else
	{
		destroy(root->left);
		destroy(root->right);
		free(root);
	}
}

int my_set_height(MY_SET hMY_SET)			//return the height of the AVL Tree implementation.
{							//An empty tree has height 0, a tree with one node has height 1
	return 0;
}		
				
