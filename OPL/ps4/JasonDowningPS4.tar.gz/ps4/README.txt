This assignment is based on SICP Section 2.3, "Symbolic Data,"
including 2.3.1, "Quotation," and 2.3.2, "Symbolic Differentiation."


Do your work in three files: 

exercise2-57.rkt: extending the differentiator to handle sums and
products of length 2+. 

exercise2-58.rkt: Converting the differentiator to infix. Do
subproblem (a) only (infix with full parenthesis and binary
operators). 

exercises.rkt: Assorted exercises relating to quoting and the various
forms of equality.

We strongly suggest you do ex. 2.58 *BEFORE* doing ex. 2.57. 

2.58(a) is much simpler than 2.57.



