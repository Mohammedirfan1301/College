make -C ./Debug clean
make -C ./Debug
./Debug/LineDemo
